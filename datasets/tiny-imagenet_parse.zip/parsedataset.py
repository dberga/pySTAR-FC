import csv
import cv2
import matplotlib.pyplot as plt
import os
import numpy as np
from nltk.corpus import wordnet as wn
import shutil

###DOWNLOAD TINY IMAGENET FROM http://cs231n.stanford.edu/tiny-imagenet-200.zip

def readboxes(boxlistpath):
    with open(boxlistpath) as csvDataFile:
        csvReader = csv.reader(csvDataFile, delimiter='	')
        data=[]
        for row in csvReader:
            data.append(row)
        return data

'''    
#test readboxes
for box in readboxes('train/n01443537/n01443537_boxes.txt'):
    print(box[0])
'''
def cropimages(labelpath):
    pathname,foldername=os.path.split(labelpath)
    imagespath=''.join([labelpath,'/','images'])
    boxlistpath=''.join([labelpath,'/',foldername,'_boxes.txt'])
    boxes=readboxes(boxlistpath)
    boxespath=''.join([labelpath,'/','boxes'])
    os.mkdir(boxespath)
    for box in boxes:
        imagepath=''.join([imagespath,'/',box[0]])
        img=cv2.imread(imagepath)
        coords=[int(box[1]),int(box[2]),int(box[3]),int(box[4])] 
        croppedimg=img[coords[1]:coords[3],coords[0]:coords[2],:] #xmin,ymin,xmax,ymax
        croppedpath=''.join([boxespath,'/',box[0]])
        cv2.imwrite(croppedpath,croppedimg)

'''
#test cropimages
cropimages('train2/n01443537')
'''


def cropall(trainpath):
    for (dirpath, dirnames, filenames) in os.walk(trainpath):
        for dirname in dirnames:
            dirnamepath=''.join([trainpath,'/',dirname])
            cropimages(dirnamepath)


      
            
def wnid2lemma(strwnid):
    split_strwnid=strwnid.split('n')
    wnid=int(split_strwnid[1])
    ss=wn._synset_from_pos_and_offset('n',wnid)
    lemma=ss.lemmas()[0].name()
    return lemma
'''
#test wnid2lemma
print(wnid2lemma('n01443537'))
'''

def renamewnids(trainpath):
    pathname,foldername=os.path.split(trainpath)
    for (dirpath, dirnames, filenames) in os.walk(trainpath):
        for dirname in dirnames:
            dirnamepath=''.join([trainpath,'/',dirname])
            boxeslistpath=''.join([trainpath,'/',dirname,'/',dirname,'_boxes.txt'])
            new_boxeslistpath=''.join([trainpath,'/',dirname,'/',wnid2lemma(dirname),'_boxes.txt'])
            new_dirnamepath=''.join([trainpath,'/',wnid2lemma(dirname)])
            os.rename(boxeslistpath, new_boxeslistpath)
            os.rename(dirnamepath, new_dirnamepath)


def copy2singlefolder(trainpath,outpath='training_boundingboxes',target='boxes'):
    os.mkdir(outpath)
    for (dirpath, dirnames, filenames) in os.walk(trainpath):
        for dirname in dirnames:
            dirnamepath=''.join([trainpath,'/',dirname])
            boxespath=''.join([dirnamepath,'/',target])
            source=os.listdir(boxespath)
            
            print(boxespath)
            destination = ''.join([outpath,'/',dirname])
            os.mkdir(destination)
            
            for files in source:
                filespath=''.join([boxespath,'/',files])
                #if files.endswith(".JPEG"):
                shutil.copy(filespath,destination)
                
###get bounding boxes as images
#cropall('train2')        

###convert wn offsets to words
#renamewnids('train2')

###copy images and bboxes to a single folder
#copy2singlefolder('train2','training_boundingboxes','boxes')
#copy2singlefolder('train2','images','images')




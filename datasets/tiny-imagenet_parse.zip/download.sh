


wget http://cs231n.stanford.edu/tiny-imagenet-200.zip


echo "Downloading SALICON dataset Images"
export fileid=1g8j-hTT-51IG1UFwP0xTGhLdgIUCW5e5 && export filename=images.zip
wget -O $filename 'https://docs.google.com/uc?export=download&id='$fileid && unzip images.zip

echo "Downloading SALICON dataset Fixations"
export fileid=0B2hsWbciDVedS1lBZHprdXFoZkU && export filename=fixations.zip
wget -O $filename 'https://docs.google.com/uc?export=download&id='$fileid && unzip fixations.zip

echo "Downloading SALICON dataset Fixation Maps"
export fileid=0B2hsWbciDVedNWJZMlRxeW1PY1U && export filename=fixations.zip
wget -O $filename 'https://docs.google.com/uc?export=download&id='$fileid && unzip fixations.zip



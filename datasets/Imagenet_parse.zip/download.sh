
echo "Downloading ILSVRC2012 Training Images"
wget http://www.image-net.org/challenges/LSVRC/2012/nnoupb/ILSVRC2012_img_train.tar
mkdir images
tar -C images -xvf ILSVRC2012_img_train.tar
for f in images/*.tar; do tar -C images -xvf $f; done
rm images/*.tar

echo "Downloading ILSVRC2012 Validation Images"
wget http://www.image-net.org/challenges/LSVRC/2012/nnoupb/ILSVRC2012_img_val.tar
mkdir images_val
tar -C images_val -xvf ILSVRC2012_img_val.tar
for f in images_val/*.tar; do tar -C images_val -xvf $f; done
rm images_val/*.tar


echo "Downloading ILSVRC2012 Test Images"
wget http://www.image-net.org/challenges/LSVRC/2012/nnoupb/ILSVRC2012_img_test.tar
mkdir images_test
tar -C images_test -xvf ILSVRC2012_img_test.tar
for f in images_test/*.tar; do tar -C images_test -xvf $f; done
rm images_test/*.tar



#echo "Downloading ILSVRC2012 (Task3) DevKit"
#wget http://www.image-net.org/challenges/LSVRC/2012/nnoupb/ILSVRC2012_devkit_t3.tar.gz


#echo "Downloading ILSVRC2012 (Task3) Training Images"
#wget http://www.image-net.org/challenges/LSVRC/2012/nnoupb/ILSVRC2012_img_train_t3.tar
#mkdir images
#tar -C images -xvf ILSVRC2012_img_train_t3.tar
#for f in images/*.tar; do tar -C images -xvf $f; done
#rm images/*.tar
##rm ILSVRC2012_img_train_t3.tar


#echo "Downloading Annotations (Task3) - Bounding Boxes and Classes"
#wget http://www.image-net.org/challenges/LSVRC/2012/nnoupb/ILSVRC2012_bbox_train_dogs.tar.gz
#mkdir annotations
#tar -C annotations -xvzf ILSVRC2012_bbox_train_dogs.tar.gz
#mv annotations/*/*.xml annotations
#rmdir annotations/*/
##rm ILSVRC2012_bbox_train_dogs.tar.gz




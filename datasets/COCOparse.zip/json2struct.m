function [ out_struct ] = json2struct( json_path )

fid = fopen(json_path); 
raw = fread(fid,inf); 
str = char(raw'); 
fclose(fid); 
out_struct = jsondecode(str);

end


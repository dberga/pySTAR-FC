function [ mask ] = segmentation2mask( segmentation, height, width )

    try
        if isstruct(segmentation)
            try 
                mask=MaskApi.decode(segmentation);
            catch
                cd cocoapi/MatlabAPI; 
                mex('CFLAGS=\$CFLAGS -Wall-std=c99','-largeArrayDims','private/maskApiMex.c','../common/maskApi.c','-I../common/','-outdir','private');
                cd ..;
                mask=MaskApi.decode(segmentation);
            end
            
        elseif ~iscell(segmentation)
                mask=zeros(height,width);
                segmentation=round(segmentation); %round mask decimals to pixels
                yi=segmentation(mod(1:length(segmentation),2) == 0); %pairs
                yi(find(yi<1))=1;
                yi(find(yi>height))=height;
                xi=segmentation(mod(1:length(segmentation),2) == 1); %odds
                xi(find(xi<1))=1;
                xi(find(xi>width))=width;
                mask=poly2mask(xi,yi,height,width);
        else
            mask=zeros(height,width);
            for i=1:length(segmentation)
                segmentation{i}=round(segmentation{i}); %round mask decimals to pixels
                yi=segmentation{i}(mod(1:length(segmentation{i}),2) == 0); %pairs
                yi(find(yi<1))=1;
                yi(find(yi>height))=height;
                xi=segmentation{i}(mod(1:length(segmentation{i}),2) == 1); %odds
                xi(find(xi<1))=1;
                xi(find(xi>width))=width;
                submask=poly2mask(xi,yi,height,width);
                mask=max(mask,submask);
            end
        end
    catch
            disp('Error when generating segmentation');
    end
end




instances_json_path='annotations/instances_train2014.json';
captions_json_path='annotations/captions_train2014.json';

% try
% 	load data.mat
%   apiresult.data=data;
% catch
% 	data=json2struct(json_path);
% 	save('data.mat','data','-v7.3');
    addpath('cocoapi/MatlabAPI');
    apiresult=CocoApi(instances_json_path);
    apiresult_captions=CocoApi(captions_json_path);
%     data=apiresult.data;
%     inds=apiresult.inds;
%     save('data.mat','data','-v7.3');
%     save('inds.mat','inds','-v7.3');
%     clearvars -except data    
% end

images_path=['images/train2014'];
%imgList=listpath(images_path);
images_parsed_path=['images_parsed'];


%% extract masks
masks_bbox_path=['boundingboxes_mask'];
imgs_bbox_path=['boundingboxes'];
masks_segmentation_path=['masks'];
captions_path=['captions'];


system(['rm -rf ' captions_path]);
for i=1:length(apiresult_captions.data.annotations)
    disp([int2str(i) '/' int2str(length(apiresult_captions.data.annotations))]);
    
    imageinfo=apiresult_captions.data.images(apiresult_captions.inds.imgIdsMap(apiresult_captions.inds.annImgIds(i)));
    anninfo=apiresult_captions.data.annotations(apiresult_captions.inds.annIdsMap(apiresult_captions.inds.annIds(i)));
    
    img_name=imageinfo.file_name;
    img_name_noext=remove_extension(imageinfo.file_name);

    %% create captions
    mkdir([captions_path]);
    if ~exist([captions_path '/' img_name_noext '.txt'],'file')
        fileID = fopen([captions_path '/' img_name_noext '.txt'],'w');
        fprintf(fileID,[anninfo.caption '\n']);
    else
        %read existing captions until the last
        fileID = fopen([captions_path '/' img_name_noext '.txt'],'r');
        tline = fgetl(fileID);
        while ischar(tline)
            last_caption=tline;
            tline = fgetl(fileID);
        end
        %append caption after the last
        if ~strcmp(last_caption,anninfo.caption)
            fileID = fopen([captions_path '/' img_name_noext '.txt'],'a+');
            fprintf(fileID,[anninfo.caption '\n']);
        end
    end
    fclose(fileID);
end

system(['rm -rf ' imgs_bbox_path]);
system(['rm -rf ' masks_bbox_path]);
system(['rm -rf ' masks_segmentation_path]);
for i=1:length(apiresult.data.annotations)
    disp([int2str(i) '/' int2str(length(apiresult.data.annotations))]);
    
    %% get image, image name, resol and category
    categoryinfo=apiresult.data.categories(apiresult.inds.catIdsMap(apiresult.inds.annCatIds(i)));
    imageinfo=apiresult.data.images(apiresult.inds.imgIdsMap(apiresult.inds.annImgIds(i)));
    anninfo=apiresult.data.annotations(apiresult.inds.annIdsMap(apiresult.inds.annIds(i)));
    
    category_name=categoryinfo.name;
    img_name=imageinfo.file_name;
    img_name_noext=remove_extension(imageinfo.file_name);
    img=imread([images_path '/' img_name ]);
    M=imageinfo.height;
    N=imageinfo.width;
    
    %% copy images to categories folders
    mkdir([images_parsed_path '/' category_name]);
    %copyfile([images_path '/' img_name ],[images_parsed_path '/' category_name '/' img_name]);
	imwrite(img,[images_parsed_path '/' category_name '/' img_name_noext '.png']);
    
    %% create bboxes 
    mkdir([masks_bbox_path '/' category_name]);
    mkdir([imgs_bbox_path '/' category_name]);
	bbox=apiresult.data.annotations(i).bbox;
	bbox_img=bbox2img(bbox,img);
	mask_bbox=bbox2mask(bbox,M,N)*255;
	imwrite(bbox_img,[imgs_bbox_path '/' category_name '/' img_name_noext '.png']);
    imwrite(mask_bbox,[masks_bbox_path '/' category_name '/' img_name_noext '.png']);
    
    %% create segmentation masks
    mkdir([masks_segmentation_path '/' category_name]);
    segmentation=apiresult.data.annotations(i).segmentation;
    mask_segment=segmentation2mask(segmentation,M,N)*255;
	imwrite(mask_segment,[masks_segmentation_path '/' category_name '/' img_name_noext '.png']);
    
    
end






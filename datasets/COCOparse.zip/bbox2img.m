function [ bbox_img ] = bbox2img( bbox, img)
	bbox=round(bbox); %round mask decimals to pixels
    bbox(find(bbox<1))=1;
    if bbox(2)+bbox(4)>size(img,1)
        bbox(4)=size(img,1)-bbox(2);
    end
    if bbox(1)+bbox(3)>size(img,2)
        bbox(3)=size(img,2)-bbox(1);
    end
    bbox(find(bbox<1))=1;
    
    bbox_img=img(bbox(2):bbox(2)+bbox(4),bbox(1):bbox(1)+bbox(3),:);
end


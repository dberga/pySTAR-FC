
echo "Downloading MSCOCO 2014 Training Images"
wget http://images.cocodataset.org/zips/train2014.zip
unzip train2014.zip
mv train2014 images
#rm train2014.zip

echo "Downloading MSCOCO 2014 Annotations"
wget http://images.cocodataset.org/annotations/annotations_trainval2014.zip
unzip annotations_trainval2014.zip 
#mv annotations/*/*.xml annotations
#rm annotations_trainval2014.zip

echo "Cloning cocoapi repo"
git clone https://github.com/cocodataset/cocoapi.git


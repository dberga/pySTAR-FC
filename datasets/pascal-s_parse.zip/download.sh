
echo "Downloading Images, SOD Masks and Annotations"
wget -O "pascal-s.zip" "https://owncloud.cvc.uab.es/owncloud/index.php/s/UXWrgCk9nJ5KrXC/download"
unzip pascal-s.zip
rm pascal-s.zip

echo "Parsing Annotations (Bounding Boxes and Classes)"
matlab -nodesktop -r "parse_annotations; exit;"


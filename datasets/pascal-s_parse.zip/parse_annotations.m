
load imgList.mat


annotations_folder='annotations';
masks_folder='masks';
images_folder='images';

out_images='images_parsed'; mkdir(out_images);
out_bboxfolder='boundingboxes'; mkdir(out_bboxfolder);
out_bboxmaskfolder='boundingboxes_mask'; mkdir(out_bboxmaskfolder);
out_objectsfolder='objects'; mkdir(out_objectsfolder);

for i=1:length(imgList)
    [folder,filename,ext]=fileparts([images_folder '/' imgList{i}]);
    image_path=[images_folder '/' filename '.jpg'];
    mask_path=[masks_folder '/' filename '.png'];
    annotation_path=[annotations_folder '/' filename '.xml'];
    
    img=imread(image_path);
    mask=imread(mask_path);
    mask(mask>0)=255; %discard object discrimination / depth
    
    annotation_struct=xml2struct(annotation_path);
    bbox=zeros(str2num(annotation_struct.annotation.size.height.Text),str2num(annotation_struct.annotation.size.width.Text));
    objcell={};
    for o=1:length(annotation_struct.annotation.object)
        try
            objname=annotation_struct.annotation.object{o}.name.Text;
            objcoords=[str2num(annotation_struct.annotation.object{o}.bndbox.xmin.Text),str2num(annotation_struct.annotation.object{o}.bndbox.ymin.Text),str2num(annotation_struct.annotation.object{o}.bndbox.xmax.Text),str2num(annotation_struct.annotation.object{o}.bndbox.ymax.Text)];
            objbbox=img(objcoords(2):objcoords(4),objcoords(1):objcoords(3),:);
            objbbox_mask=mask(objcoords(2):objcoords(4),objcoords(1):objcoords(3),:);
            mkdir([out_bboxfolder '/' objname]);
            mkdir([out_bboxmaskfolder '/' objname ]);
            mkdir([out_images '/' objname ]);
            imwrite(objbbox,[out_bboxfolder '/' objname '/' filename '_' num2str(o) '_' objname '.png']);
            imwrite(objbbox_mask,[out_bboxmaskfolder '/' objname '/' filename '_' num2str(o) '_' objname '.png']);
            imwrite(img,[out_images '/' objname '/' filename '.png']);
            objcell{o}=objname;
        end
    end
    save([out_objectsfolder '/' filename '.mat'],'objcell');
end

